#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import PoseStamped
import math
from nav2_simple_commander.robot_navigator import BasicNavigator, TaskResult
import time

class EBotNavigator(Node):

    def __init__(self):
        super().__init__('ebot_navigator')
        self.navigator = BasicNavigator()

        init_pose = PoseStamped()
        init_pose.header.frame_id = 'map'
        init_pose.header.stamp = self.navigator.get_clock().now().to_msg()
        init_pose.pose.position.x = 1.84
        init_pose.pose.position.y = -9.05
        yaw = 3.14
        qz = math.sin(yaw / 2.0)
        qw = math.cos(yaw / 2.0)
        init_pose.pose.orientation.z = qz
        init_pose.pose.orientation.w = qw

        self.navigator.setInitialPose(init_pose)

        # Poses to navigate
        self.goals = [
            [-0.12, -2.35, 3.14],  # P1
            [1.86, 2.56, 0.97],    # P2
            [-3.84, 2.64, 2.78],    # P3
            [1.84, -9.05, 3.14]
        ]

        # Tolerances
        self.pose_tolerance = 0.3  # Reduce tolerance to be more precise
        self.orientation_tolerance = math.radians(10)  # 5 degrees tolerance

    def navigate_to_pose(self, pose):
        goal_pose = PoseStamped()
        goal_pose.header.frame_id = 'map'
        goal_pose.header.stamp = self.navigator.get_clock().now().to_msg()

        # Set x, y position
        goal_pose.pose.position.x = pose[0]
        goal_pose.pose.position.y = pose[1]

        # Convert yaw (in radians) to quaternion for orientation
        yaw = pose[2]
        qz = math.sin(yaw / 2.0)
        qw = math.cos(yaw / 2.0)
        goal_pose.pose.orientation.z = qz
        goal_pose.pose.orientation.w = qw

        # Send goal
        self.navigator.goToPose(goal_pose)

    def run(self):
        # Wait for Nav2 stack to fully activate
        self.navigator.waitUntilNav2Active()

        for goal in self.goals:
            self.get_logger().info(f'Navigating to {goal}')
            self.navigate_to_pose(goal)

            # Poll for task completion
            while not self.navigator.isTaskComplete():
                feedback = self.navigator.getFeedback()
                if feedback.navigation_time.sec > 600:
                    self.navigator.cancelTask()

            # Check the final result
            result = self.navigator.getResult()

            if result == TaskResult.SUCCEEDED:
                self.get_logger().info('Goal reached successfully!')
            elif result == TaskResult.CANCELED:
                self.get_logger().info('Goal was canceled.')
                break
            else:
                self.get_logger().info('Goal failed.')

            # Add a delay only after the task is completed
            self.get_logger().info('Pausing for 3 seconds before the next goal...')
            time.sleep(3)  # Delay before moving to the next goal

        # Shutdown after reaching all goals
        self.navigator.lifecycleShutdown()

def main(args=None):
    rclpy.init(args=args)
    navigator = EBotNavigator()
    navigator.run()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
